package Application.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
import java.util.UUID;
@ResponseStatus(code = HttpStatus.NOT_FOUND)


public class ProductsNotFoundException extends RuntimeException
{
    public ProductsNotFoundException(UUID productsId)
    {
    super(String.format("Для идентификатора продукта [%s] отсутствует запись в таблице", productsId));
    }
}