package Application.service;

import Application.dto.ProductsDTO;
import Application.entity.Products;
import Application.exception.ProductsNotFoundException;
import Application.repository.ProductsRepository;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;
@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)

public class ProductsService {
    ProductsRepository productsRepository;

    @Transactional(readOnly = true)
    public List<Products> getProducts() {return productsRepository.findAll();}

    @Transactional
    public void saveProducts(ProductsDTO productsDTO) {
        Products products = Products.builder()
                .name(productsDTO.getProduct_name())
                .price(productsDTO.getProduct_price())
                .amount(productsDTO.getProduct_amount())
                .build();

        productsRepository.save(products);
    }

    @Transactional
    public void updateProducts(ProductsDTO productsDTO) {
        Optional<Products> productsOptional = productsRepository.findById(productsDTO.getId());
        if (productsOptional.isPresent())
        {
            Products products = productsOptional.get();
            products.setName(productsDTO.getProduct_name());
            products.setPrice(productsDTO.getProduct_price());
            products.setAmount(productsDTO.getProduct_amount());
            productsRepository.save(products);
        }
        else
        {
            throw new ProductsNotFoundException(productsDTO.getId());
        }
    }

    @Transactional
    public void deleteProducts(ProductsDTO productsDTO) {
        Optional<Products> productsOptional = productsRepository.findById(productsDTO.getId());
        if (productsOptional.isPresent()) {
            productsRepository.deleteById(productsDTO.getId());
        }
        else
        {
            throw new ProductsNotFoundException(productsDTO.getId());
        }
    }
}