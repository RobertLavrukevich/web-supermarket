package Application.dto;

import lombok.*;
import lombok.experimental.FieldDefaults;
import java.util.UUID;
@Data
@Builder
@NoArgsConstructor@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)

public class ProductsDTO
{
    UUID id;
    String product_name;
    float product_price;
    int product_amount;
}