package Application.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.FieldDefaults;
import org.hibernate.annotations.GenericGenerator;
import javax.persistence.*;
import java.util.UUID;
@Builder
@Data
@Entity
@Table(name = "Products")
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)

public class Products {
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(
            name = "UUID",
            strategy = "org.hibernate.id.UUIDGenerator"
    )
    @JsonProperty(value = "id")
    UUID id;

    @Column(name = "product_name")
    @JsonProperty(value = "name")
    String name;

    @Column(name = "product_price")
    @JsonProperty(value = "price")
    Float price;

    @Column(name = "product_amount")
    @JsonProperty(value = "amount")
    Integer amount;
}


