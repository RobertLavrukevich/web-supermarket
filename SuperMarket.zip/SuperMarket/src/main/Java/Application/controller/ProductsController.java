package Application.controller;

import Application.dto.ProductsDTO;
import Application.entity.Products;
import Application.service.ProductsService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
@RestController
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)

public class ProductsController {
    ProductsService productsService;
    @GetMapping("/products")
    public ResponseEntity<List<Products>> getAllProducts()
    {
        return ResponseEntity.ok(productsService.getProducts());
    }
    @PostMapping("/products-save")
    public ResponseEntity<Void> saveProducts(@RequestBody ProductsDTO productsDTO)
    {
        productsService.saveProducts(productsDTO);
        return ResponseEntity.ok().build();
    }
    @PostMapping("/products-update")
    public ResponseEntity<Void> updateProducts(@RequestBody ProductsDTO productsDTO)
    {
        productsService.updateProducts(productsDTO);
        return ResponseEntity.ok().build();
    }
    @PostMapping("/products-delete")
    public ResponseEntity<Void> deleteProducts(@RequestBody ProductsDTO productsDTO)
    {
        productsService.deleteProducts(productsDTO);
        return  ResponseEntity.ok().build();
    }
}

